package com.example.tecnico.apkmoney;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;

class Cliente extends WebViewClient {
    Activity activity;

    public Cliente(Activity act) {
        this.activity = act;
    }

    public boolean shouldOverrideUrlLoading(WebView webView, String url) {
        if (url.contains("scaleproject.000webhostapp.com/login.php")) return false;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        activity.startActivity(intent);
        return true;
    }
}
